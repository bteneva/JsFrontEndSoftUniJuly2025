const loadButtonEl = document.querySelector("#load-records")
loadButtonEl.addEventListener('click', handleLoadRecords);

const addRecordBtn = document.getElementById("add-record")
addRecordBtn.addEventListener('click', handleAddRecord);

const editRecordBtn = document.getElementById("edit-record")
editRecordBtn.addEventListener('click', handleEditRecord);

const listUlElements = document.querySelector("#list")

const nameInputFormElement = document.getElementById("p-name")
const stepsInputFormElement = document.getElementById("steps")
const caloriesInputFormElement = document.getElementById("calories")

const BASE_URL = 'http://localhost:3030/jsonstore/records'

async function handleLoadRecords() {
    const recordsResp = await fetch(BASE_URL);
    const recordsData = await recordsResp.json()
    const recordsArr = Object.values(recordsData);

    listUlElements.innerHTML = '';

    recordsArr.forEach(record => {
        const listItemEl = document.createElement('li');
        listItemEl.classList.add('record');

        const infoDivElement = document.createElement('div')
        infoDivElement.classList.add('info');

        const namePEl = document.createElement('p')
        namePEl.textContent = record.name;
        
        const stepPEl = document.createElement('p')
        stepPEl.textContent = record.steps;

        const caloriePEl = document.createElement('p')
        caloriePEl.textContent = record.calories;

        const buttonsDivEl = document.createElement('div')
        buttonsDivEl.classList.add("btn-wrapper")

        const changeButtonEl = document.createElement('button')
        changeButtonEl.classList.add("change-btn")
        changeButtonEl.textContent = "Change"

        const deleteButtonEl = document.createElement('button')
        deleteButtonEl.classList.add("delete-btn")
        deleteButtonEl.textContent = "Delete"

        infoDivElement.appendChild(namePEl)
        infoDivElement.appendChild(caloriePEl)
        infoDivElement.appendChild(stepPEl)

        buttonsDivEl.appendChild(changeButtonEl)
        buttonsDivEl.appendChild(deleteButtonEl)

        listItemEl.appendChild(infoDivElement)
        listItemEl.appendChild(buttonsDivEl)

        listUlElements.appendChild(listItemEl)
    



    })
    
}

async function handleEditRecord() {
    
}

async function handleAddRecord() {
    
}

