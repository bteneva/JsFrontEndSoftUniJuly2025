const BASE_URL = 'http://localhost:3030/jsonstore/movies'

const titleInput = document.querySelector("#title")
const directorInput = document.querySelector("#director");
const releaseYearInput = document.querySelector("#year")

const addMovieButton = document.querySelector("#add-movie")
addMovieButton.textContent = "Add Movie"
//addMovieButton.addEventListener('click', handleAdd)


const editMovieButton = document.querySelector("#edit-movie")
//editMovieButton.addEventListener('click', handleEdit)

const loadMoviesButton = document.querySelector("#load-movies")
loadMoviesButton.addEventListener('click', handleLoad)

const movieListDiv = document.querySelector("#movie-list")

async function handleLoad() {

    const recordsResp = await fetch(BASE_URL);
    const recordsData = await recordsResp.json()
    const recordsArr = Object.values(recordsData);
    

    movieListDiv.innerHTML = ''

    recordsArr.forEach(record => {

        const divMovie = document.createElement('div')
        divMovie.classList.add("movie")

        const movieDivContetn = document.createElement('div')
        movieDivContetn.classList.add("content")

        const titlePEl = document.createElement('p')
        titlePEl.textContent = record.title
        const directorPEl = document.createElement('p')
        directorPEl.textContent = record.director
        const yearPEl = document.createElement('p')
        yearPEl.textContent = record.year

        const buttonsDiv = document.createElement('div')
        const changeButton = document.createElement('button')
        changeButton.classList.add("change-btn")
        const deleteButton = document.createElement('button')
        deleteButton.classList.add("delete-btn")
        buttonsDiv.appendChild(changeButton)
        buttonsDiv.appendChild(deleteButton)

        movieDivContetn.appendChild(titlePEl)
        movieDivContetn.appendChild(directorPEl)
        movieDivContetn.appendChild(yearPEl)

        divMovie.appendChild(movieDivContetn)
        divMovie.appendChild(buttonsDiv)

        movieListDiv.appendChild(divMovie)
        
    });
}



   

  

    



 


